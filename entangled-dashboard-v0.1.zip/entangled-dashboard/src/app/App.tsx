import { useMemo, useState } from "react";
import ArchivePage from "../features/archive/ArchivePage";
import { saveReading } from "../features/archive/readingStorage";
import AstrologyPage from "../features/astrology/AstrologyPage";
import { getLiveAstroContext } from "../features/astrology/liveAstroEngine";
import { getNatalLensForPacket } from "../features/astrology/natalLens";
import ExperimentalPage from "../features/experimental/ExperimentalPage";
import type { LlmStatus } from "../features/llm/llmTypes";
import RunesPage from "../features/runes/RunesPage";
import SettingsPage from "../features/settings/SettingsPage";
import SynthesisPage from "../features/synthesis/SynthesisPage";
import type { ReadingPacket } from "../features/synthesis/readingPacket";
import TarotPage from "../features/tarot/TarotPage";
import DashboardHome from "./DashboardHome";
import DashboardShell from "./layout/DashboardShell";
import type { AppRouteId } from "./routes";

export default function App() {
  const [activeRoute, setActiveRoute] = useState<AppRouteId>("dashboard");
  const [currentPacket, setCurrentPacket] = useState<ReadingPacket | undefined>();
  const liveAstrology = useMemo(() => getLiveAstroContext(), []);
  const natalLens = useMemo(() => getNatalLensForPacket(currentPacket), [currentPacket]);
  const llmStatus: LlmStatus = currentPacket?.llmSynthesis?.status ?? "disabled";

  function handleCreatePacket(packet: ReadingPacket) {
    setCurrentPacket(packet);
  }

  function handleUpdatePacket(packet: ReadingPacket) {
    setCurrentPacket(packet);
  }

  function handleSavePacket() {
    if (currentPacket) saveReading(currentPacket);
  }

  return (
    <DashboardShell
      activeRoute={activeRoute}
      onRouteChange={setActiveRoute}
      liveAstrology={liveAstrology}
      currentPacket={currentPacket}
      llmStatus={llmStatus}
    >
      {activeRoute === "dashboard" && (
        <DashboardHome
          currentPacket={currentPacket}
          liveAstrology={liveAstrology}
          natalLens={natalLens}
          onRouteChange={setActiveRoute}
          onSavePacket={handleSavePacket}
        />
      )}
      {activeRoute === "tarot" && <TarotPage currentPacket={currentPacket} onCreatePacket={handleCreatePacket} />}
      {activeRoute === "runes" && <RunesPage currentPacket={currentPacket} onCreatePacket={handleCreatePacket} />}
      {activeRoute === "astrology" && <AstrologyPage liveAstrology={liveAstrology} natalLens={natalLens} />}
      {activeRoute === "synthesis" && (
        <SynthesisPage currentPacket={currentPacket} onUpdatePacket={handleUpdatePacket} />
      )}
      {activeRoute === "experimental" && <ExperimentalPage currentPacket={currentPacket} />}
      {activeRoute === "archive" && <ArchivePage currentPacket={currentPacket} onLoadPacket={setCurrentPacket} />}
      {activeRoute === "settings" && <SettingsPage />}
    </DashboardShell>
  );
}
