export type RuneDatum = {
  id: string;
  name: string;
  glyph?: string;
  aett?: string;
  keywords?: string[];
  meanings?: string[];
  cautions?: string[];
  prompts?: string[];
};

export type RuneReadingMode = "single" | "three-rune" | "freehand-cast";

export type RuneReadingOptions = {
  mode: RuneReadingMode;
  userQuestion?: string;
};
