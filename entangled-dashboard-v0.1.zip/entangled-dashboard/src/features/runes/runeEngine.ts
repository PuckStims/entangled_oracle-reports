import runePlaceholder from "../../data/runes/elder-futhark.placeholder.json";
import { getLiveAstroContext } from "../astrology/liveAstroEngine";
import { getNatalLensForPacket } from "../astrology/natalLens";
import { buildLocalSynthesis } from "../synthesis/localSynthesis";
import {
  collectStaticInterpretation,
  createEmptyStaticInterpretation,
  makePacketId,
  type ReadingPacket,
  type RuneCastGeometry,
  type SymbolEntry
} from "../synthesis/readingPacket";
import type { RuneDatum, RuneReadingMode, RuneReadingOptions } from "./runeTypes";

const runeCatalog = runePlaceholder as RuneDatum[];

export function getRuneCatalogStatus() {
  return {
    count: runeCatalog.length,
    ready: runeCatalog.length >= 24,
    note:
      runeCatalog.length === 0
        ? "Rune adapter is scaffolded. Wire your existing Elder Futhark JSON in runeEngine.ts."
        : `Rune adapter loaded ${runeCatalog.length} runes.`
  };
}

function runeCountForMode(mode: RuneReadingMode): number {
  if (mode === "single") return 1;
  if (mode === "three-rune") return 3;
  return Math.min(9, runeCatalog.length);
}

function chooseRunes(count: number): RuneDatum[] {
  return [...runeCatalog].sort(() => Math.random() - 0.5).slice(0, count);
}

function toSymbolEntry(rune: RuneDatum, index: number): SymbolEntry {
  return {
    id: rune.id,
    name: rune.name,
    glyph: rune.glyph,
    modality: "runes",
    keywords: rune.keywords ?? [],
    meaning: rune.meanings?.join(" "),
    caution: rune.cautions?.join(" "),
    prompts: rune.prompts,
    position: `Rune ${index + 1}`,
    source: "rune-json"
  };
}

function buildPlaceholderGeometry(symbols: SymbolEntry[], mode: RuneReadingMode): RuneCastGeometry | undefined {
  if (mode !== "freehand-cast") return undefined;

  return {
    matName: "Freehand cast adapter",
    points: symbols.map((symbol, index) => ({
      runeId: symbol.id,
      x: 0.5,
      y: 0.5,
      region: `Region adapter ${index + 1}`
    })),
    notes: ["Freehand geometry is scaffolded. Wire your existing cast system here."]
  };
}

export function createRuneReading(options: RuneReadingOptions): ReadingPacket {
  const symbols = chooseRunes(runeCountForMode(options.mode)).map(toSymbolEntry);
  const geometry = buildPlaceholderGeometry(symbols, options.mode);

  const packet: ReadingPacket = {
    id: makePacketId("runes"),
    createdAt: new Date().toISOString(),
    modality: "runes",
    readingMode: "standard",
    userQuestion: options.userQuestion?.trim() || undefined,
    symbols,
    layout: {
      spreadName: options.mode,
      runeCastGeometry: geometry
    },
    staticInterpretation: symbols.length ? collectStaticInterpretation(symbols) : createEmptyStaticInterpretation(),
    liveAstrology: getLiveAstroContext(),
    sourceTrace: {
      usedTarotJson: false,
      usedRuneJson: symbols.length > 0,
      usedLiveAstrology: false,
      usedNatalLens: false,
      usedOpenRouter: false,
      missing: [
        ...(symbols.length ? [] : (["rune-json"] as const)),
        "live-astrology",
        "natal-lens",
        "openrouter"
      ]
    }
  };

  packet.natalLens = getNatalLensForPacket(packet);
  packet.localSynthesis = buildLocalSynthesis(packet);
  return packet;
}
