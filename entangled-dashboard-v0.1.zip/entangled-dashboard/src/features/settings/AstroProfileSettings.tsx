import { LockKeyhole } from "lucide-react";

export default function AstroProfileSettings() {
  return (
    <section className="data-card">
      <div className="card-title-row">
        <LockKeyhole />
        <h2>Astro Profile</h2>
      </div>
      <p>
        Exact natal data should stay local unless you intentionally publish it. Use a
        <code> .local.json</code> file for private profile routing.
      </p>
      <dl className="detail-list">
        <div>
          <dt>Scaffold adapter</dt>
          <dd>
            <code>src/features/astrology/natalLens.ts</code>
          </dd>
        </div>
        <div>
          <dt>Placeholder</dt>
          <dd>
            <code>src/data/astrology/profile.placeholder.json</code>
          </dd>
        </div>
        <div>
          <dt>Private pattern</dt>
          <dd>
            <code>src/data/astrology/puck.profile.local.json</code>
          </dd>
        </div>
      </dl>
    </section>
  );
}
