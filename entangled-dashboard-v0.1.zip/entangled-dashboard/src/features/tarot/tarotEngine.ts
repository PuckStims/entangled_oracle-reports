import tarotPlaceholder from "../../data/tarot/tarot-78.placeholder.json";
import { getLiveAstroContext } from "../astrology/liveAstroEngine";
import { getNatalLensForPacket } from "../astrology/natalLens";
import { buildLocalSynthesis } from "../synthesis/localSynthesis";
import {
  collectStaticInterpretation,
  createEmptyStaticInterpretation,
  makePacketId,
  type ReadingPacket,
  type ReadingPosition,
  type SymbolEntry
} from "../synthesis/readingPacket";
import type { TarotCardDatum, TarotReadingOptions, TarotSpread, TarotSpreadId } from "./tarotTypes";

const tarotCatalog = tarotPlaceholder as TarotCardDatum[];

export const tarotSpreads: TarotSpread[] = [
  {
    id: "single",
    label: "Single Card",
    cardCount: 1,
    positionLabels: ["Card 1"]
  },
  {
    id: "three-card",
    label: "Three Card",
    cardCount: 3,
    positionLabels: ["Card 1", "Card 2", "Card 3"]
  },
  {
    id: "celtic-cross",
    label: "Celtic Cross",
    cardCount: 10,
    positionLabels: Array.from({ length: 10 }, (_, index) => `Celtic Cross ${index + 1}`)
  }
];

export function getTarotCatalogStatus() {
  return {
    count: tarotCatalog.length,
    ready: tarotCatalog.length >= 78,
    note:
      tarotCatalog.length === 0
        ? "Tarot adapter is scaffolded. Wire your existing 78-card JSON in tarotEngine.ts."
        : `Tarot adapter loaded ${tarotCatalog.length} cards.`
  };
}

export function getTarotSpread(spreadId: TarotSpreadId): TarotSpread {
  return tarotSpreads.find((spread) => spread.id === spreadId) ?? tarotSpreads[0];
}

function chooseCards(count: number): TarotCardDatum[] {
  return [...tarotCatalog].sort(() => Math.random() - 0.5).slice(0, count);
}

function toSymbolEntry(card: TarotCardDatum, position: ReadingPosition, allowReversals: boolean): SymbolEntry {
  return {
    id: card.id,
    name: card.name,
    modality: "tarot",
    keywords: card.keywords ?? [],
    meaning: card.meanings?.join(" "),
    caution: card.cautions?.join(" "),
    prompts: card.prompts,
    position: position.label,
    reversed: allowReversals ? Math.random() > 0.5 : false,
    source: "tarot-json"
  };
}

export function createTarotReading(options: TarotReadingOptions): ReadingPacket {
  const spread = getTarotSpread(options.spreadId);
  const positions: ReadingPosition[] = spread.positionLabels.map((label, index) => ({
    id: `${spread.id}-${index + 1}`,
    label,
    meaning: "Position meaning adapter not wired."
  }));

  const cards = chooseCards(spread.cardCount);
  const symbols = cards.map((card, index) => toSymbolEntry(card, positions[index], options.allowReversals));

  const packet: ReadingPacket = {
    id: makePacketId("tarot"),
    createdAt: new Date().toISOString(),
    modality: "tarot",
    readingMode: "standard",
    userQuestion: options.userQuestion?.trim() || undefined,
    symbols,
    layout: {
      spreadName: spread.label,
      positions
    },
    staticInterpretation: symbols.length ? collectStaticInterpretation(symbols) : createEmptyStaticInterpretation(),
    liveAstrology: getLiveAstroContext(),
    sourceTrace: {
      usedTarotJson: symbols.length > 0,
      usedRuneJson: false,
      usedLiveAstrology: false,
      usedNatalLens: false,
      usedOpenRouter: false,
      missing: [
        ...(symbols.length ? [] : (["tarot-json"] as const)),
        "live-astrology",
        "natal-lens",
        "openrouter"
      ]
    }
  };

  packet.natalLens = getNatalLensForPacket(packet);
  packet.localSynthesis = buildLocalSynthesis(packet);
  return packet;
}
