import { useMemo, useState } from "react";
import { Shuffle, WandSparkles } from "lucide-react";
import type { ReadingPacket } from "../synthesis/readingPacket";
import { createTarotReading, getTarotCatalogStatus } from "./tarotEngine";
import type { TarotSpreadId } from "./tarotTypes";
import TarotCardView from "./TarotCardView";
import TarotSpreadSelector from "./TarotSpreadSelector";

type TarotPageProps = {
  currentPacket?: ReadingPacket;
  onCreatePacket: (packet: ReadingPacket) => void;
};

export default function TarotPage({ currentPacket, onCreatePacket }: TarotPageProps) {
  const [spreadId, setSpreadId] = useState<TarotSpreadId>("single");
  const [allowReversals, setAllowReversals] = useState(true);
  const [question, setQuestion] = useState("");
  const status = useMemo(() => getTarotCatalogStatus(), []);
  const tarotPacket = currentPacket?.modality === "tarot" ? currentPacket : undefined;

  function handlePull() {
    onCreatePacket(
      createTarotReading({
        spreadId,
        allowReversals,
        userQuestion: question
      })
    );
  }

  return (
    <main className="page-grid">
      <section className="section-panel section-panel--wide">
        <div className="section-kicker">
          <WandSparkles size={16} />
          Standard Practice
        </div>
        <h1>Tarot</h1>
        <p>
          The card practice is scaffolded around your existing 78-card JSON. Until that dataset is
          wired, this tab shows the spread controls and packet path without inventing card meanings.
        </p>
      </section>

      <section className="control-panel">
        <h2>Reading Setup</h2>
        <TarotSpreadSelector selected={spreadId} onChange={setSpreadId} />
        <label className="field-label">
          Question or focus
          <textarea value={question} onChange={(event) => setQuestion(event.target.value)} />
        </label>
        <label className="toggle-row">
          <input
            type="checkbox"
            checked={allowReversals}
            onChange={(event) => setAllowReversals(event.target.checked)}
          />
          Reversals allowed
        </label>
        <button className="primary-action" type="button" onClick={handlePull}>
          <Shuffle size={18} />
          Create Tarot Packet
        </button>
      </section>

      <section className="data-card">
        <h2>Catalog Status</h2>
        <p className={status.ready ? "status-good" : "status-muted"}>{status.note}</p>
        <dl className="detail-list">
          <div>
            <dt>Loaded cards</dt>
            <dd>{status.count}</dd>
          </div>
          <div>
            <dt>Expected</dt>
            <dd>78</dd>
          </div>
        </dl>
      </section>

      <section className="section-panel section-panel--wide">
        <h2>Current Tarot Packet</h2>
        {tarotPacket?.symbols.length ? (
          <div className="symbol-grid">
            {tarotPacket.symbols.map((symbol) => (
              <TarotCardView key={`${symbol.id}-${symbol.position}`} symbol={symbol} />
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <p>No tarot symbols are present yet. Wire the existing dataset, then create a packet.</p>
          </div>
        )}
      </section>
    </main>
  );
}
