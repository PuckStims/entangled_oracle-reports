export type TarotCardDatum = {
  id: string;
  name: string;
  arcana?: string;
  suit?: string;
  number?: string | number;
  keywords?: string[];
  meanings?: string[];
  cautions?: string[];
  prompts?: string[];
};

export type TarotSpreadId = "single" | "three-card" | "celtic-cross";

export type TarotSpread = {
  id: TarotSpreadId;
  label: string;
  cardCount: number;
  positionLabels: string[];
};

export type TarotReadingOptions = {
  spreadId: TarotSpreadId;
  userQuestion?: string;
  allowReversals: boolean;
};
