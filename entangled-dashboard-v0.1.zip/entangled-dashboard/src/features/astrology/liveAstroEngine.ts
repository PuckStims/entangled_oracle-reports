import placeholder from "../../data/astrology/live-astro.placeholder.json";
import type { LiveAstroContext } from "./astroTypes";

export function getLiveAstroContext(): LiveAstroContext {
  return {
    status: "not_wired",
    generatedAt: new Date().toISOString(),
    adapterName: "liveAstroEngine.placeholder",
    note:
      typeof placeholder.note === "string"
        ? placeholder.note
        : "Wire this function to your existing astrology engine."
  };
}

export function getAstrologyReadiness(context = getLiveAstroContext()): {
  label: string;
  ready: boolean;
  detail: string;
} {
  if (context.status === "available") {
    return {
      label: "Live sky online",
      ready: true,
      detail: "The astrology adapter is returning structured context."
    };
  }

  return {
    label: "Live sky scaffolded",
    ready: false,
    detail: context.note ?? "The adapter exists, but no live astrology source is connected."
  };
}
