import { CircleDashed, LockKeyhole, Orbit } from "lucide-react";
import type { LiveAstroContext, NatalLensResult } from "./astroTypes";

type AstrologyPageProps = {
  liveAstrology: LiveAstroContext;
  natalLens: NatalLensResult;
};

export default function AstrologyPage({ liveAstrology, natalLens }: AstrologyPageProps) {
  return (
    <main className="page-grid">
      <section className="section-panel section-panel--wide">
        <div className="section-kicker">
          <Orbit size={16} />
          Sky Adapter
        </div>
        <h1>Astrology Layer</h1>
        <p>
          This wing is intentionally scaffold-only. It exposes the place where your existing
          astrology engine can provide live context without inventing signs, phases, aspects, or
          natal routing in this repository.
        </p>
      </section>

      <section className="data-card">
        <div className="card-title-row">
          <CircleDashed />
          <h2>Live Sky Context</h2>
        </div>
        <dl className="detail-list">
          <div>
            <dt>Status</dt>
            <dd>{liveAstrology.status}</dd>
          </div>
          <div>
            <dt>Adapter</dt>
            <dd>{liveAstrology.adapterName}</dd>
          </div>
          <div>
            <dt>Generated</dt>
            <dd>{new Date(liveAstrology.generatedAt).toLocaleString()}</dd>
          </div>
          <div>
            <dt>Note</dt>
            <dd>{liveAstrology.note}</dd>
          </div>
        </dl>
      </section>

      <section className="data-card">
        <div className="card-title-row">
          <LockKeyhole />
          <h2>Personal Natal Lens</h2>
        </div>
        <dl className="detail-list">
          <div>
            <dt>Status</dt>
            <dd>{natalLens.status}</dd>
          </div>
          <div>
            <dt>Adapter</dt>
            <dd>{natalLens.adapterName}</dd>
          </div>
          <div>
            <dt>Routes</dt>
            <dd>{natalLens.routes.length}</dd>
          </div>
          <div>
            <dt>Note</dt>
            <dd>{natalLens.note}</dd>
          </div>
        </dl>
      </section>
    </main>
  );
}
