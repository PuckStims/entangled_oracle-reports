import placeholder from "../../data/astrology/profile.placeholder.json";
import type { NatalLensResult } from "./astroTypes";
import type { ReadingPacket } from "../synthesis/readingPacket";

export function getNatalLensForPacket(_packet?: ReadingPacket): NatalLensResult {
  return {
    status: "not_wired",
    adapterName: "natalLens.placeholder",
    note:
      typeof placeholder.note === "string"
        ? placeholder.note
        : "Wire this adapter to a private .local.json profile or existing natal engine.",
    routes: []
  };
}
