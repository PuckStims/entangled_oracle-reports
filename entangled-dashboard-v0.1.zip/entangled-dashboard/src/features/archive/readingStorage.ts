import type { ReadingPacket } from "../synthesis/readingPacket";

const STORAGE_KEY = "entangled-dashboard.readings.v0";

export function listArchivedReadings(): ReadingPacket[] {
  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (!raw) return [];

  try {
    const parsed = JSON.parse(raw) as ReadingPacket[];
    return Array.isArray(parsed)
      ? parsed.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      : [];
  } catch {
    return [];
  }
}

export function saveReading(packet: ReadingPacket): ReadingPacket[] {
  const readings = listArchivedReadings();
  const next = [packet, ...readings.filter((reading) => reading.id !== packet.id)];
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  return next;
}

export function deleteReading(packetId: string): ReadingPacket[] {
  const next = listArchivedReadings().filter((reading) => reading.id !== packetId);
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  return next;
}

export function clearReadings(): void {
  window.localStorage.removeItem(STORAGE_KEY);
}
