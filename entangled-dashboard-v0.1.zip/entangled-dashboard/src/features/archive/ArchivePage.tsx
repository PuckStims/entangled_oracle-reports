import { useEffect, useState } from "react";
import { Archive, Save, Trash2 } from "lucide-react";
import type { ReadingPacket } from "../synthesis/readingPacket";
import ReadingDetail from "./ReadingDetail";
import { deleteReading, listArchivedReadings, saveReading } from "./readingStorage";

type ArchivePageProps = {
  currentPacket?: ReadingPacket;
  onLoadPacket: (packet: ReadingPacket) => void;
};

export default function ArchivePage({ currentPacket, onLoadPacket }: ArchivePageProps) {
  const [readings, setReadings] = useState<ReadingPacket[]>([]);
  const [selectedId, setSelectedId] = useState<string | undefined>();
  const selected = readings.find((reading) => reading.id === selectedId);

  useEffect(() => {
    setReadings(listArchivedReadings());
  }, []);

  function handleSaveActive() {
    if (!currentPacket) return;
    setReadings(saveReading(currentPacket));
    setSelectedId(currentPacket.id);
  }

  function handleDelete(packetId: string) {
    const next = deleteReading(packetId);
    setReadings(next);
    if (selectedId === packetId) setSelectedId(undefined);
  }

  return (
    <main className="page-grid">
      <section className="section-panel section-panel--wide">
        <div className="section-kicker">
          <Archive size={16} />
          Pattern Memory
        </div>
        <h1>Archive</h1>
        <p>
          Saved readings are stored locally in the browser as packet JSON. This makes the archive
          useful before any database is added.
        </p>
        <button className="primary-action" type="button" disabled={!currentPacket} onClick={handleSaveActive}>
          <Save size={18} />
          Save Active Packet
        </button>
      </section>

      <section className="data-card">
        <h2>Saved Packets</h2>
        {readings.length ? (
          <div className="reading-list">
            {readings.map((reading) => (
              <button
                type="button"
                key={reading.id}
                className={selectedId === reading.id ? "reading-list__item is-active" : "reading-list__item"}
                onClick={() => {
                  setSelectedId(reading.id);
                  onLoadPacket(reading);
                }}
              >
                <span>{reading.modality}</span>
                <strong>{new Date(reading.createdAt).toLocaleString()}</strong>
                <small>{reading.symbols.length} symbols</small>
              </button>
            ))}
          </div>
        ) : (
          <p>No saved readings yet.</p>
        )}
      </section>

      <section className="data-card">
        <h2>Archive Controls</h2>
        <button
          className="secondary-action secondary-action--danger"
          type="button"
          disabled={!selectedId}
          onClick={() => selectedId && handleDelete(selectedId)}
        >
          <Trash2 size={16} />
          Delete Selected
        </button>
      </section>

      <ReadingDetail packet={selected ?? currentPacket} />
    </main>
  );
}
