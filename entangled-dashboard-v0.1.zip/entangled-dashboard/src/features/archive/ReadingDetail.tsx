import { Braces } from "lucide-react";
import type { ReadingPacket } from "../synthesis/readingPacket";
import { summarizeSourceTrace } from "../synthesis/sourceTrace";

type ReadingDetailProps = {
  packet?: ReadingPacket;
};

export default function ReadingDetail({ packet }: ReadingDetailProps) {
  if (!packet) {
    return (
      <section className="section-panel">
        <h2>Reading Detail</h2>
        <p>Select an archived packet to inspect it.</p>
      </section>
    );
  }

  return (
    <section className="section-panel section-panel--wide">
      <div className="card-title-row">
        <Braces />
        <h2>Reading Detail</h2>
      </div>
      <dl className="detail-list detail-list--grid">
        <div>
          <dt>ID</dt>
          <dd>{packet.id}</dd>
        </div>
        <div>
          <dt>Modality</dt>
          <dd>{packet.modality}</dd>
        </div>
        <div>
          <dt>Symbols</dt>
          <dd>{packet.symbols.length}</dd>
        </div>
        <div>
          <dt>Created</dt>
          <dd>{new Date(packet.createdAt).toLocaleString()}</dd>
        </div>
      </dl>
      <ul className="clean-list">
        {summarizeSourceTrace(packet).map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
      <details className="json-details">
        <summary>Packet JSON</summary>
        <pre>{JSON.stringify(packet, null, 2)}</pre>
      </details>
    </section>
  );
}
