# Entangled Astrology v0.1

Native Android scaffold for **Entangled Astrology**, one application in the wider **Entangled** ecosystem. The frontend is intentionally incapable of inventing astrology content. Until a real Entangled Oracle engine is connected, calculation surfaces remain visibly unconfigured or empty.

## What is real in this repository

- Kotlin + Jetpack Compose Android application
- Mobile-first five-tab navigation: Today, Timeline, Chart, Places, Library
- Local birth-profile and accessibility storage through DataStore
- Typed `AstrologyEngine` boundary
- Functional Ktor API client
- Strict Kotlin serialization
- Configurable backend URL and connection diagnostics
- Current Field, timeline, natal chart, Place Resonance, report-job contracts
- Calculation provenance and supporting-event requirements
- Response validation that rejects unsupported field synthesis
- Entangled ecosystem switcher
- No runtime sample charts, transits, interpretations, or scores

## What is deliberately not fabricated

The repository contains no successful fake API implementation. Until Codex wraps the real engine, the app displays honest connection, loading, empty, and error states.

## Open in Android Studio

Requirements:

- Android Studio compatible with AGP 9.2
- JDK 17+
- Android SDK 37 and Build Tools 36.0.0+

Open the repository root and allow Gradle sync. From a terminal:

```bash
./gradlew test lintDebug assembleDebug
```

Windows:

```bat
gradlew.bat test lintDebug assembleDebug
```

## Connect a development backend

1. Run the future FastAPI adapter on the development computer, normally port 8000.
2. In an Android emulator, open Settings → Engine & accessibility.
3. Set the URL to `http://10.0.2.2:8000`.
4. Save and test the connection.
5. Create a birth profile and explicitly request a calculation.

For a physical Android device, use an HTTPS address or a reachable LAN address. Cleartext HTTP is enabled for development only and must be restricted before release.

## Handoff to Codex

Give Codex:

- this repository,
- the Entangled Oracle engine repository or selected files,
- the current CLI command,
- a known-good raw output,
- a known-good report,
- ephemeris setup and environment requirements.

Then use `docs/CODEX_BACKEND_BUILD_PROMPT.md`.

## Version posture

This is v0.1: a complete integration-oriented frontend scaffold, not a claim that the backend or consumer release is finished.

## Gradle bootstrap note

This ZIP includes a small audited bootstrap `gradle-wrapper.jar` because the build environment used to assemble the repository could not download binary wrapper artifacts directly. It reads `gradle-wrapper.properties`, verifies the configured Gradle distribution SHA-256, extracts it safely, and launches Gradle. Its local offline smoke test is documented in `docs/GRADLE_BOOTSTRAP.md`.

After the first successful sync, the integration developer may replace it with Gradle's standard generated wrapper by running:

```bash
./gradlew wrapper --gradle-version 9.4.1
```
