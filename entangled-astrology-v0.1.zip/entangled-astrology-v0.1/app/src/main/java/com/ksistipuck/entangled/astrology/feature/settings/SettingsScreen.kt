package com.ksistipuck.entangled.astrology.feature.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ksistipuck.entangled.astrology.app.AppUiState
import com.ksistipuck.entangled.astrology.app.AppViewModel
import com.ksistipuck.entangled.astrology.core.designsystem.*
import com.ksistipuck.entangled.astrology.core.repository.EngineConnectionState

@Composable
fun SettingsScreen(state: AppUiState, viewModel: AppViewModel) {
    var url by remember(state.settings?.engineBaseUrl) { mutableStateOf(state.settings?.engineBaseUrl.orEmpty()) }
    val settings = state.settings
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        ScreenTitle("Integration", "Engine & accessibility", "The app is useful only when its calculation source is explicit.")
        EntangledCard(Modifier.fillMaxWidth()) {
            Text("Entangled Oracle connection", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(url, { url = it }, label = { Text("Backend URL") }, supportingText = { Text("Android emulator to host computer: http://10.0.2.2:8000") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { viewModel.saveEngineUrl(url) }) { Text("Save") }
                OutlinedButton(onClick = { viewModel.saveAndTestEngineUrl(url) }) { Text("Test") }
            }
            when (val connection = state.connection) {
                EngineConnectionState.Unconfigured -> Text("Not configured", color = EntangledColors.Muted)
                EngineConnectionState.Checking -> LinearProgressIndicator(Modifier.fillMaxWidth())
                is EngineConnectionState.Failed -> Text(connection.message, color = MaterialTheme.colorScheme.error)
                is EngineConnectionState.Connected -> {
                    Text("Connected: ${connection.identity.engine} ${connection.identity.engineVersion}", color = EntangledColors.Verdigris)
                    Text("Schema ${connection.identity.schemaVersion} · ${connection.capabilities.supportedTechniques.size} techniques")
                }
            }
        }
        EntangledCard(Modifier.fillMaxWidth()) {
            Text("Accessibility", style = MaterialTheme.typography.titleLarge)
            SettingSwitch("Reduced motion", settings?.reducedMotion ?: false, viewModel::setReducedMotion)
            SettingSwitch("Low-stimulation presentation", settings?.lowStimulation ?: false, viewModel::setLowStimulation)
            SettingSwitch("High contrast", settings?.highContrast ?: false, viewModel::setHighContrast)
            Text("Text scale ${"%.1f".format(settings?.textScale ?: 1f)}×")
            Slider(value = settings?.textScale ?: 1f, onValueChange = viewModel::setTextScale, valueRange = 0.9f..1.4f, steps = 4)
        }
        EntangledCard(Modifier.fillMaxWidth()) {
            Text("Privacy posture", style = MaterialTheme.typography.titleLarge)
            Text("Birth profiles and preferences are stored locally with DataStore. Calculation requests are sent only to the URL you configure. HTTP logging is disabled. Cloud backup is disabled for app data.", color = EntangledColors.Muted)
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
